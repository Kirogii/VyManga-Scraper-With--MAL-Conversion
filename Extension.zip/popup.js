let completedPages = 0;
let baseUrl = '';

// Get base URL from current tab when popup opens
chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  const currentUrl = tabs[0].url;
  const urlDisplay = document.getElementById('currentUrl');
  
  if (currentUrl.includes('vymanga.com')) {
    // Extract base URL up to '?page=' or just the URL if no page parameter
    baseUrl = currentUrl.split('?page=')[0];
    urlDisplay.textContent = `Processing: ${baseUrl}`;
    document.getElementById('start').disabled = false;
  } else {
    urlDisplay.textContent = 'Please navigate to a vymanga.com page';
    document.getElementById('start').disabled = true;
  }
});

async function fetchPage(pageNum) {
  try {
    const pageUrl = `${baseUrl}?page=${pageNum}`;
    const response = await fetch(pageUrl);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const text = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'text/html');
    
    // First method: Extract manga items based on "manga-info" class
    const mangaItems = doc.querySelectorAll('.manga-info');
    let pageData = [];
    
    mangaItems.forEach(item => {
      const titleElement = item.querySelector('img');
      const chapterElement = item.querySelector('.chapter .text-success');
      
      if (titleElement) {
        const title = titleElement.getAttribute('title');
        let chapter = '';
        
        // Check for chapter number if it exists
        if (chapterElement) {
          const chapterMatch = chapterElement.textContent.match(/\d+/);
          chapter = chapterMatch ? ` - Chapter ${chapterMatch[0]}` : '';
        }
        
        pageData.push(`${title}${chapter}`);
      }
    });

    // If the first method yields no results, try the second method for collections
    if (pageData.length === 0) {
      const collectionItems = doc.querySelectorAll('.col-lg-2 .comic-item');
      collectionItems.forEach(item => {
        const titleElement = item.querySelector('.comic-title');
        const chapterElement = item.querySelector('.tray-item');

        if (titleElement) {
          const title = titleElement.textContent.trim();
          let chapter = '';
          
          if (chapterElement) {
            chapter = chapterElement.textContent.trim();
          }
          
          pageData.push(`${title} - ${chapter}`);
        }
      });
    }

    return pageData;
  } catch (error) {
    console.error(`Error processing page ${pageNum}:`, error);
    throw error;
  }
}

function updateProgress(totalPages) {
  completedPages++;
  const progressBar = document.querySelector('.progress-fill');
  const progressText = document.getElementById('progress');
  const percentage = (completedPages / totalPages) * 100;
  
  progressBar.style.width = `${percentage}%`;
  progressText.textContent = `Processed ${completedPages} of ${totalPages} pages`;
}

document.getElementById('start').addEventListener('click', async () => {
  const startButton = document.getElementById('start');
  const progress = document.getElementById('progress');
  const output = document.getElementById('output');
  const copyBtn = document.getElementById('copyBtn');
  const downloadBtn = document.getElementById('downloadBtn');
  const progressBar = document.querySelector('.progress-fill');
  const errorDiv = document.getElementById('error');
  
  // Reset UI
  startButton.disabled = true;
  copyBtn.style.display = 'none';
  downloadBtn.style.display = 'none';
  output.textContent = '';
  errorDiv.textContent = '';
  progressBar.style.width = '0%';
  completedPages = 0;
  
  const totalPages = parseInt(document.getElementById('pages').value) || 1;
  progress.textContent = 'Starting processing...';
  
  try {
    // Process pages in batches of 5
    const batchSize = 25;
    const mangaList = [];
    
    for (let i = 1; i <= totalPages; i += batchSize) {
      const batch = Array.from(
        { length: Math.min(batchSize, totalPages - i + 1) },
        (_, index) => i + index
      );
      
      const batchResults = await Promise.all(batch.map(fetchPage));
      
      batchResults.forEach((pageData) => {
        mangaList.push(...pageData);
        updateProgress(totalPages);
      });
    }
    
    // Format and display results
    const malFormatted = mangaList.map(manga => `- ${manga}`).join('\n');
    output.textContent = malFormatted;
    
    // Enable buttons
    startButton.disabled = false;
    copyBtn.style.display = 'block';
    downloadBtn.style.display = 'block';
    progress.textContent = 'Processing complete!';
    
    // Setup copy button
    copyBtn.onclick = () => {
      navigator.clipboard.writeText(malFormatted);
      copyBtn.textContent = 'Copied!';
      setTimeout(() => {
        copyBtn.textContent = 'Copy to Clipboard';
      }, 2000);
    };
    
    // Setup download button
    downloadBtn.onclick = () => {
      const blob = new Blob([malFormatted], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'manga-list.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    };
  } catch (error) {
    errorDiv.textContent = `Error: ${error.message}`;
    startButton.disabled = false;
    progress.textContent = 'Processing failed';
  }
});

document.getElementById('setPages').addEventListener('click', () => {
  const pagesInput = document.getElementById('pages');
  if (pagesInput.value < 1) {
    pagesInput.value = 1;
  }
});
