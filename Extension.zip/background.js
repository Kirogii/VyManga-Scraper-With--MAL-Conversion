chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extractManga") {
        const mangaList = [];
        const parser = new DOMParser();
        const doc = parser.parseFromString(request.html, 'text/html');
        
        const mangaItems = doc.querySelectorAll('.history-item');
        mangaItems.forEach(item => {
            const titleElement = item.querySelector('.name');
            const chapterElement = item.querySelector('.chapter .text-success');
            if (titleElement && chapterElement) {
                const title = titleElement.textContent.trim();
                const chapter = chapterElement.textContent.trim();
                mangaList.push(`${title} - ${chapter}`);
            }
        });
        
        sendResponse({ mangaList });
    }
    return true; // Keep the message channel open for asynchronous response
});